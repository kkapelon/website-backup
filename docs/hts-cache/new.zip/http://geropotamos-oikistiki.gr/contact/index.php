<!DOCTYPE html>
<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->

<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="keywords" content="Επικοινωνία, , " />
<meta name="description" content="Επικοινωνία, " />
<meta name="rating" content="general" />
<meta name="author" content="Γεροπόταμος Οικιστική " />
<meta name="copyright" content="2011 - 2024, Γεροπόταμος Οικιστική " />
<meta name="revisit-after" content="5 Days" />
<meta name="expires" content="never" />
<meta name="distribution" content="global" />
<meta name="robots" content="index" />

<title>Επικοινωνία - ΓΕΡΟΠΟΤΑΜΟΣ Ανώνυμος Οικιστική Εταιρεία ( Υπό εκκαθάριση))</title>

<!-- ////////////////////////////////// -->
<!-- //      Stylesheets Files       // -->
<!-- ////////////////////////////////// -->
<link rel="stylesheet" href="../css/base.css" id="camera-css"/>
<link rel="stylesheet" href="../css/framework.css"/>
<link rel="stylesheet" href="../css/style.css"/>
<link rel="stylesheet" href="../css/media.css"/>
<link rel="stylesheet" href="../css/noscript.css" media="screen,all" id="noscript"/>
<style type="text/css">
body {
	background-color: #94A9FF;
}
</style>

<!-- ////////////////////////////////// -->
<!-- //     Google Webfont Files     // -->
<!-- ////////////////////////////////// -->
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300,300italic,700&subset=latin,greek-ext,greek' rel='stylesheet' type='text/css'>

<!-- ////////////////////////////////// -->
<!-- //        Favicon Files         // -->
<!-- ////////////////////////////////// -->
<link rel="icon" href="http://www.loggia.gr/new/assets/files/images/pages/page_icons/4919_geropotamos_icon.jpg" type="image/x-icon" />
<link rel="shortcut icon" href="http://www.loggia.gr/new/assets/files/images/pages/page_icons/4919_geropotamos_icon.jpg" type="image/x-icon" />
<link rel="apple-touch-icon" href="http://www.loggia.gr/new/assets/files/images/pages/page_icons/"/>

<!-- ////////////////////////////////// -->
<!-- //      Javascript Files        // -->
<!-- ////////////////////////////////// -->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script src="../js/jquery.easing-1.3.min.js"></script>
<script src="../js/tooltip.js"></script>
<script src="../js/superfish.js"></script>
<script src="../js/tinynav.min.js"></script>
<script src="../js/jquery.mobile.customized.min.js"></script>
<script src="../js/jquery.fancybox.js?v=2.0.6"></script>
<script src="../js/jquery.fancybox-media.js?v=1.0.3"></script>
<script src="../js/jquery.ui.totop.min.js"></script>
<script src="../js/ddaccordion.js"></script>
<script src="../js/jquery.twitter.js"></script>
<script src="../js/faq-functions.js" ></script>
<script src="../js/contact-form.js"></script>
<script src="../js/jquery.googlemaps1.01.js"></script>
<script src="http://maps.google.com/maps?file=api&amp;v=2&amp;sensor=false&amp;key=AIzaSyBbNN6v1D00y6mUXbtPUnB7_b8c-Xs1ing"></script>
<script type="text/javascript">
$(document).ready(function() { 
    
  $('#map_canvas').googleMaps({
	  scroll: false,
	  latitude: 35.390994,
	  longitude: 24.562181,
	  depth: 12, 
	  markers: [
                        {
                latitude: 35.365779,
                longitude: 24.468551            },            {
                latitude: 35.416209,
                longitude: 24.655811            },          ]
   }); 
}); 
</script>

<script>
	jQuery(document).ready(function($) {
		//Mainmenu
		$('ul#menu').superfish();
		
		//Fade portfolio
		$(".fade").fadeTo(1, 1);
		$(".fade").hover(
		function () {$(this).fadeTo("fast", 0.45);},
		function () { $(this).fadeTo("slow", 1);}
		);		
		
		//Tab Jquery
		$(".tab_content").hide(); 
		$("ul.tabs li:first").addClass("active").show(); 
		$(".tab_content:first").show(); 
		$("ul.tabs li").click(function() {
			$("ul.tabs li").removeClass("active");
			$(this).addClass("active"); 
			$(".tab_content").hide(); 
			var activeTab = $(this).find("a").attr("href"); 
			$(activeTab).fadeIn(); 
			return false;
		});	
		
				
		//Fancybox Jquery
		$(".fancybox").fancybox({
			padding: 0,
			openEffect : 'elastic',
			openSpeed  : 250,
			closeEffect : 'elastic',
			closeSpeed  : 250,
			closeClick : true,
			helpers : {
				overlay : {opacity : 0.65},
				media : {}
			}
		});	
		
		//TinyNav Jquery
		$('#menu').tinyNav({
		  active: 'selected'
		});		
		
		//To top Jquery
		$().UItoTop({ easingType: 'easeOutQuart' });							
	});	    
	
	$(document).ready(function() { 
	  
	  //Camera Jquery
	  $('#camera-slide').camera({		
		  thumbnails: false,
		  hover: false,
		  fx: 'fade',
		  time: 7000,
		  transPeriod: 500,
		  pagination: false,
	  });	  	
	});
</script>

<!-- IE Fix for HTML5 Tags -->
<!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->

</head>
<body>

<div id="main-wrapper">
	
    <!-- header start here -->
	<header>
    	<div id="top_wrapper">
            <div class="row">
                <div class="four column logo">
                    <a href="../index.php?langid=45"><img src="http://www.loggia.gr/new/assets/files/images/pages/profile/9468_6.jpg" name="ΓΕΡΟΠΟΤΑΜΟΣ Ανώνυμος Οικιστική Εταιρεία ( Υπό εκκαθάριση))" alt="ΓΕΡΟΠΟΤΑΜΟΣ Ανώνυμος Οικιστική Εταιρεία ( Υπό εκκαθάριση))" /></a>
                </div>
				<div class="top_search">
                </div>            
            </div>
        </div>
        
        <div id="mainmenu_wrapper">
            <!-- mainmenu start here -->
                   <nav id="mainmenu" >
                <ul id="menu">
                    <li><a href="../index.php?langid=45">Αρχική</a></li>
                                       
                     
                                        
 					                    	<li class="dropdown"><a href="../market/index.php?langid=45">Υπηρεσίες</a>
                        	<ul> 
                				                        			<li><a href="../market/list.php?cat=2305&langid=45">ΑΝΑΚΟΙΝΩΣΕΙΣ</a></li>
                    			                            	                        	</ul> 
                    	</li>
                       
                                        
                     
                	                	
                                    	
                    	
                		                        		<li><a href="../articles/list.php?cat=1916&langid=45">ΔΗΜΟΣΙΕΥΣΕΙΣ</a></li>
                    			                            	                        	
                    	
                                          
                     
                	<!--<li><a href="profile/index.php?langid=45">Προφίλ</a></li>-->
                        
                    

                        <li><a href="../media/gallery.php?langid=45">Φωτογραφίες</a></li>


                                           
                    <li><a href="../contact/index.php?langid=45">Επικοινωνία</a></li>
                </ul>
            </nav>            <!-- mainmenu end here -->
            
            <!-- top socials start here -->
            <div id="top-socials">
                <ul class="socials-list">
                                                        </ul>
            </div>
            <!-- top socials end here -->
        </div>             
    </header>
    <!-- header end here -->
    
    <!-- pagetitle start here -->
	<section id="pagetitle-wrapper">
    	<div class="row">
        	<div class="twelve columns">
            	<h3>Επικοινωνία</h3>
                <p>Στοιχεία επικοινωνίας</p>
            </div>
            <div class="twelve columns">
            	<div id="breadcrumb">
                	<ul>
                        <li><a href="../index.php?langid=45"><img src="../images/breadcrumb_home.png" alt="Αρχική" /></a></li>
                        <li class="current-page"><a href="#">Επικοινωνία</a></li>
                    </ul>
                </div>
            </div>
        </div>           
    </section>
    <!-- pagetitle end here -->
    
    <!-- google map start here -->
    <section id="map-wrapper">
        <div id="map_canvas"></div>
    </section>
    <!-- google map end here -->
    
    <!-- content section start here -->
    <section id="content-wrapper">
    
        <div class="row contact-wrap-info">
            <div class="four columns mobile-two">
            								
            		<img src="../images/icons/icon123.png" alt="" class="img-left" />
            		<h5></h5>
					<p>
						<br />
					</p>
					                                    
            </div> 
            <div class="four columns mobile-two">            
                                    <img src="../images/icons/icon108.png" alt="" class="img-left" />
                    <h5></h5>
                    <p>ΣΤΑΜΑΘΙΟΥΔΑΚΗ 8  Ρέθυμνο, 74100</p>
                                    <img src="../images/icons/icon108.png" alt="" class="img-left" />
                    <h5>ΠΟΛΕΟΔΟΜΙΚΗ ΕΚΤΑΣΗ</h5>
                    <p>ΠΑΝΟΡΜΟ ΠΑΡΝΑΜΟΣ Μυλοπόταμος, 74054</p>
                            </div>
            <div class="four columns mobile-two">
            	<img src="../images/icons/icon231.png" alt="" class="img-left" />
                <h5>Email</h5>
                <p><a href="mailto:stel@otenet.gr">stel@otenet.gr</a></p>
            </div>
        </div>
        
        <div class="row">
            <div class="twelve columns">
                <div class="divider"></div>
            </div>
        </div>
        
        <div class="row contact-wrap-form">
        	<div class="eight columns">
            	<div id="contact-form-area">
                    <!-- Contact Form Start //-->
                    <form action="#" id="contactform"> 
                        <fieldset>
                            <div class="label-form-inline"> 
                            <label>Όνομα <em>*</em></label>                           
                            <input type="text" name="name" class="textfield" id="name" value="" /> 
                            </div>
                            <div class="label-form-inline">
                            <label>Email <em>*</em></label> 
                            <input type="text" name="email" class="textfield" id="email" value="" />  
                            </div>
                            <div class="label-form-inline-last">                      
                            <label>Θέμα</label>
                            <input type="text" name="subject" class="textfield" id="subject" value="" />
                            </div>
                        <label>Λεπτομέρειες</label>
                        <textarea name="message" id="message" class="textarea" cols="2" rows="4"></textarea>
                        <div class="clear"></div> 
                        <label>&nbsp;</label>
                        <input type="submit" name="submit" class="buttoncontact" id="buttonsend" value="Αποστολή" />
                        <span class="loading" style="display: none;">Παρακαλω περιμμένετε...</span>
                        <div class="clear"></div>
                        </fieldset> 
                    </form>
                    <!-- Contact Form End //-->
                </div>                
            </div>
           <!-- <div class="four columns">
            	<h5>Στοιχεία Επιχείρησης</h5>
            	<p></p>
				<div class="userInput">
                	<p></p>
                </div>
            </div>-->
        </div>  

    </section>
    <!-- content section end here -->
    
            
    <!-- footer start here -->
     <footer>
    	<div class="row">
            <div class="two columns mobile-two">
                                	<ul class="iconul footer-list">
                		    <li><a href="../profile/index.php">Η Εταιρεία</a></li>
                		   <!-- <li><a href="http://79.170.40.32/geropotamos-oikistiki.gr/market/index.php">Υπηρεσίες</a></li>
                		                        	<li><a href="articles/list.php?cat=1916&langid=45">ΔΗΜΟΣΙΕΥΣΕΙΣ</a></li>-->
                    	                	</ul>
                             
            </div>
            <div class="two columns mobile-two">
             	<ul class="iconul footer-list-address">
                	                    	<li><p>ΣΤΑΜΑΘΙΟΥΔΑΚΗ 8, <br />Ρέθυμνο 74100</p></li>
                    					                </ul>   
            </div>
            <div class="three columns mobile-two">
            </div>
            
            <div class="three columns">
            	<div class="copyright">
                    <a href="http://www.designgraphic.gr" target="_blank" id="dg">ΣχεδιασμόςDesignGraphic.gr</a>
                    <p>&copy; Copyright 2024 ΓΕΡΟΠΟΤΑΜΟΣ Ανώνυμος Οικιστική Εταιρεία ( Υπό εκκαθάριση))<br/> Με κάθε νόμιμο δικαίωμα</p>
                </div>
                
            </div>	
        </div>
    </footer>    <!-- footer end here -->

</div>

<script>$('#noscript').remove();</script>
</body>
</html>