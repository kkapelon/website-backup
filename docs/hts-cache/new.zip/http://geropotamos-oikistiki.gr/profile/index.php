<!DOCTYPE html>
<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->

<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="keywords" content="Προφίλ, , " />
<meta name="description" content="Προφίλ, " />
<meta name="rating" content="general" />
<meta name="author" content="Γεροπόταμος Οικιστική " />
<meta name="copyright" content="2011 - 2024, Γεροπόταμος Οικιστική " />
<meta name="revisit-after" content="5 Days" />
<meta name="expires" content="never" />
<meta name="distribution" content="global" />
<meta name="robots" content="index" />

<title>Προφίλ - ΓΕΡΟΠΟΤΑΜΟΣ Ανώνυμος Οικιστική Εταιρεία ( Υπό εκκαθάριση))</title>

<!-- ////////////////////////////////// -->
<!-- //      Stylesheets Files       // -->
<!-- ////////////////////////////////// -->
<link rel="stylesheet" href="../css/base.css" id="camera-css"/>
<link rel="stylesheet" href="../css/framework.css"/>
<link rel="stylesheet" href="../css/style.css"/>
<link rel="stylesheet" href="../css/media.css"/>
<link rel="stylesheet" href="../css/noscript.css" media="screen,all" id="noscript"/>
<style type="text/css">
body {
	background-color: #94A9FF;
}
</style>

<!-- ////////////////////////////////// -->
<!-- //     Google Webfont Files     // -->
<!-- ////////////////////////////////// -->
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300,300italic,700&subset=latin,greek-ext,greek' rel='stylesheet' type='text/css'>

<!-- ////////////////////////////////// -->
<!-- //        Favicon Files         // -->
<!-- ////////////////////////////////// -->
<link rel="icon" href="http://www.loggia.gr/new/assets/files/images/pages/page_icons/4919_geropotamos_icon.jpg" type="image/x-icon" />
<link rel="shortcut icon" href="http://www.loggia.gr/new/assets/files/images/pages/page_icons/4919_geropotamos_icon.jpg" type="image/x-icon" />
<link rel="apple-touch-icon" href="http://www.loggia.gr/new/assets/files/images/pages/page_icons/"/>

<!-- ////////////////////////////////// -->
<!-- //      Javascript Files        // -->
<!-- ////////////////////////////////// -->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script src="../js/jquery.easing-1.3.min.js"></script>
<script src="../js/tooltip.js"></script>
<script src="../js/superfish.js"></script>
<script src="../js/tinynav.min.js"></script>
<script src="../js/jquery.mobile.customized.min.js"></script>
<script src="../js/jquery.fancybox.js?v=2.0.6"></script>
<script src="../js/jquery.fancybox-media.js?v=1.0.3"></script>
<script src="../js/jquery.ui.totop.min.js"></script>
<script src="../js/ddaccordion.js"></script>
<script src="../js/jquery.twitter.js"></script>
<script src="../js/faq-functions.js" ></script>
<script>
	jQuery(document).ready(function($) {
		//Mainmenu
		$('ul#menu').superfish();
		
		//Fade portfolio
		$(".fade").fadeTo(1, 1);
		$(".fade").hover(
		function () {$(this).fadeTo("fast", 0.45);},
		function () { $(this).fadeTo("slow", 1);}
		);		
		
		//Tab Jquery
		$(".tab_content").hide(); 
		$("ul.tabs li:first").addClass("active").show(); 
		$(".tab_content:first").show(); 
		$("ul.tabs li").click(function() {
			$("ul.tabs li").removeClass("active");
			$(this).addClass("active"); 
			$(".tab_content").hide(); 
			var activeTab = $(this).find("a").attr("href"); 
			$(activeTab).fadeIn(); 
			return false;
		});	
		
				
		//Fancybox Jquery
		$(".fancybox").fancybox({
			padding: 0,
			openEffect : 'elastic',
			openSpeed  : 250,
			closeEffect : 'elastic',
			closeSpeed  : 250,
			closeClick : true,
			helpers : {
				overlay : {opacity : 0.65},
				media : {}
			}
		});	
		
		//TinyNav Jquery
		$('#menu').tinyNav({
		  active: 'selected'
		});		
		
		//To top Jquery
		$().UItoTop({ easingType: 'easeOutQuart' });							
	});	    
	
	$(document).ready(function() { 
	  
	  //Camera Jquery
	  $('#camera-slide').camera({		
		  thumbnails: false,
		  hover: false,
		  fx: 'fade',
		  time: 7000,
		  transPeriod: 500,
		  pagination: false,
	  });	  	
	});
</script>

<!-- IE Fix for HTML5 Tags -->
<!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->

</head>
<body>

<div id="main-wrapper">
	
    <!-- header start here -->
	<header>
    	<div id="top_wrapper">
            <div class="row">
                <div class="four column logo">
                    <a href="../index.php?langid=45"><img src="http://www.loggia.gr/new/assets/files/images/pages/profile/9468_6.jpg" name="ΓΕΡΟΠΟΤΑΜΟΣ Ανώνυμος Οικιστική Εταιρεία ( Υπό εκκαθάριση))" alt="ΓΕΡΟΠΟΤΑΜΟΣ Ανώνυμος Οικιστική Εταιρεία ( Υπό εκκαθάριση))" /></a>
                </div>
				<div class="top_search">
                </div>            
            </div>
        </div>
        
        <div id="mainmenu_wrapper">
        	<!-- mainmenu start here -->
            <nav id="mainmenu">
                <ul id="menu">
                    
                    <li><a href="../index.php?langid=45">Αρχική</a></li>

                     

					                    	<li class="dropdown"><a href="../market/index.php?langid=45">Υπηρεσίες</a>
                        	<ul> 
                				                        			<li><a href="../market/list.php?cat=2305&langid=45">ΑΝΑΚΟΙΝΩΣΕΙΣ</a></li>
                    			                            	                        	</ul>
                    	</li>
                               
                    
                     
                    
                                        	<li class="dropdown"><a href="../articles/index.php?langid=45">Νέα & Ανακοινώσεις</a>
                        	<ul> 
                				                        			<li><a href="../articles/list.php?cat=1916&langid=45">ΔΗΜΟΣΙΕΥΣΕΙΣ</a></li>
                    			                            	                        	</ul>
                    	</li>
                     
                     
                	<li class="selected"><a href="../profile/index.php?langid=45">Προφίλ</a></li>
                    <li><a href="../contact/index.php?langid=45">Επικοινωνία</a></li>
                </ul>
            </nav>
            <!-- mainmenu end here -->
            
            <!-- top socials start here -->
            <div id="top-socials">
                <ul class="socials-list">
                                                        </ul>
            </div>
            <!-- top socials end here -->
        </div>             
    </header>
    <!-- header end here -->
    
    <!-- pagetitle start here -->
	<section id="pagetitle-wrapper">
    	<div class="row">
        	<div class="twelve columns">
            	<h3>Προφίλ</h3>
                <p>ΓΕΡΟΠΟΤΑΜΟΣ Ανώνυμος Οικιστική Εταιρεία ( Υπό εκκαθάριση))</p>
            </div>
            <div class="twelve columns">
            	<div id="breadcrumb">
                	<ul>
                        <li><a href="../index.php?langid=45"><img src="../images/breadcrumb_home.png" alt="Αρχική" /></a></li>
                        <li class="current-page"><a href="#">Προφίλ</a></li>
                    </ul>
                </div>
            </div>
        </div>           
    </section>
    <!-- pagetitle end here -->
    
    <!-- content section start here -->
    <section id="content-wrapper">
    
        <div class="row">
            <div class="six columns">
            	<div class="userInput">
                	<img src="../images/sample_images/about.png" alt="" class="img-left" />
                	<h5>ΓΕΡΟΠΟΤΑΜΟΣ Ανώνυμος Οικιστική Εταιρεία ( Υπό εκκαθάριση))</h5>
                	<p></p>
                </div>
				<div class="userInput">
                	<p></p>
                </div>           
            </div>
            <div class="six columns">
                            </div>
          
          
            <div class="six columns">
                           

				
            </div>
          
            
            
            
        </div>
    
    </section>
    <!-- content section end here -->
    
            
    <!-- footer start here -->
     <footer>
    	<div class="row">
            <div class="two columns mobile-two">
                                	<ul class="iconul footer-list">
                		    <li><a href="../profile/index.php">Η Εταιρεία</a></li>
                		   <!-- <li><a href="http://79.170.40.32/geropotamos-oikistiki.gr/market/index.php">Υπηρεσίες</a></li>
                		                        	<li><a href="articles/list.php?cat=1916&langid=45">ΔΗΜΟΣΙΕΥΣΕΙΣ</a></li>-->
                    	                	</ul>
                             
            </div>
            <div class="two columns mobile-two">
             	<ul class="iconul footer-list-address">
                	                    	<li><p>ΣΤΑΜΑΘΙΟΥΔΑΚΗ 8, <br />Ρέθυμνο 74100</p></li>
                    					                </ul>   
            </div>
            <div class="three columns mobile-two">
            </div>
            
            <div class="three columns">
            	<div class="copyright">
                    <a href="http://www.designgraphic.gr" target="_blank" id="dg">ΣχεδιασμόςDesignGraphic.gr</a>
                    <p>&copy; Copyright 2024 ΓΕΡΟΠΟΤΑΜΟΣ Ανώνυμος Οικιστική Εταιρεία ( Υπό εκκαθάριση))<br/> Με κάθε νόμιμο δικαίωμα</p>
                </div>
                
            </div>	
        </div>
    </footer>    <!-- footer end here -->

</div>

<script>
	$('#noscript').remove();
</script>
</body>
</html>